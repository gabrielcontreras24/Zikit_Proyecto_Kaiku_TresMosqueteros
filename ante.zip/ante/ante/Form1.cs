﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ante
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
          // Cambia "button1_Click" por el nombre real de tu botón si es distinto
        private async void button1_Click(object sender, EventArgs e)
        {
            // ====== CONFIGURACIÓN ======
            // --- Simulación ---
            // Segundos reales por cada hora registrada en el CSV (0 = sin espera)
            double segundosPorHora = 0.3;

            // --- Predicción con las métricas ---
            // Cuánto debe superar cada métrica a su valor normal para considerarse elevada
            // Orden: CPU, RAM, Disco, Latencia
            double[] margenes = { 5.0, 3.0, 0.5, 20.0 };
            string[] nombres = { "CPU", "RAM", "Disco", "Latencia" };
            string[] unidades = { "%", "%", "%", " ms" };

            const int metricasMinimas = 2;          // cuántas métricas deben estar elevadas a la vez
            const int lecturasMediana = 5;          // la comparación usa la mediana de las últimas 5 lecturas
            const int minimoLecturasValidas = 3;    // mínimo de lecturas válidas (no vacías) para calcular esa mediana
            const int persistencia = 5;             // lecturas seguidas con la condición para detectar un posible error
            const int minutosParaRearmar = 120;     // sin condición durante estos minutos, la alarma se rearma
            const int lecturasCalentamiento = 120;  // lecturas necesarias para conocer el valor normal antes de alertar

            // Eventos esperados del contexto de la empresa: no se alerta durante estas ventanas
            bool silenciarEventosEsperados = true;
            const int minutosColaEvento = 30;       // minutos extra después de cada evento (solo para silenciar alertas)

            // --- Evidencia en los logs (para decidir si la alarma se muestra o se descarta como falsa) ---
            // true  = solo se muestra la alarma si en los logs ya leídos hay un aviso WARN de saturación
            // false = se muestran todas las alarmas que detecten las métricas
            bool exigirEvidenciaEnLogs = true;
            // Un log WARN cuyo mensaje contiene alguna de estas palabras cuenta como evidencia
            string[] palabrasEvidencia = { "pool de conexiones", "cpu de ", "ram de ", "memoria", "latencia", "pico de conexiones" };
            // ...salvo que contenga alguna de estas (son parte de un evento esperado, como la campana de correo)
            string[] palabrasExcluidas = { "campana", "campaña" };
            const int minutosEvidenciaLogs = 180;       // la evidencia debe ser de las últimas 3 horas
            const int minutosCondicionReciente = 15;    // y las métricas deben seguir elevadas (o haberlo estado hace poco)

            // --- Confirmación de errores con logs ---
            // El CSV registra el error 1 minuto después del log; se acepta también 1 minuto más de retraso
            int[] desfasesMetrica = { 1, 2 };
            const int logsAnteriores = 3;           // logs anteriores que se guardan junto a cada error confirmado

            // --- Comparación final alertas vs errores confirmados ---
            // Un error confirmado cuenta como predicho si ocurre durante el episodio de la alerta (o hasta
            // estos minutos después de que la métrica vuelve a la normalidad)
            const int minutosToleranciaFin = 5;
            // ===========================

            Button boton = sender as Button;
            string tituloOriginal = this.Text;
            if (boton != null) boton.Enabled = false;

            // Controles de la barra de progreso (se crean más abajo, por código)
            ProgressBar barra = null;
            Label etiquetaProgreso = null;

            try
            {
                // ---------- Elegir los DOS archivos al inicio ----------
                string ruta;
                using (OpenFileDialog dialogo = new OpenFileDialog())
                {
                    dialogo.Title = "1 de 2: selecciona el archivo CSV de métricas";
                    dialogo.Filter = "Archivos CSV (*.csv)|*.csv|Todos los archivos (*.*)|*.*";
                    if (dialogo.ShowDialog() != DialogResult.OK)
                        return;
                    ruta = dialogo.FileName;
                }

                string rutaLogs;
                using (OpenFileDialog dialogoLogs = new OpenFileDialog())
                {
                    dialogoLogs.Title = "2 de 2: selecciona el archivo de logs";
                    dialogoLogs.Filter = "Archivos de logs (*.md;*.log;*.txt)|*.md;*.log;*.txt|Todos los archivos (*.*)|*.*";
                    if (dialogoLogs.ShowDialog() != DialogResult.OK)
                        return;
                    rutaLogs = dialogoLogs.FileName;
                }

                string carpeta = System.IO.Path.GetDirectoryName(ruta);
                string nombreBase = System.IO.Path.GetFileNameWithoutExtension(ruta);
                string rutaConErrores = System.IO.Path.Combine(carpeta, nombreBase + "_con_errores.csv");
                string rutaConfirmados = System.IO.Path.Combine(carpeta, "errores_confirmados.csv");
                string rutaValidadas = System.IO.Path.Combine(carpeta, nombreBase + "_alertas_validadas.csv");

                // ---------- Barra de progreso ----------
                // Total de filas de datos (sin encabezado ni líneas vacías)
                int totalLineas = System.Linq.Enumerable.Count(
                    System.IO.File.ReadLines(ruta, System.Text.Encoding.UTF8),
                    l => !string.IsNullOrWhiteSpace(l)) - 1;
                if (totalLineas < 1) totalLineas = 1;

                etiquetaProgreso = new Label();
                etiquetaProgreso.Dock = DockStyle.Bottom;
                etiquetaProgreso.Height = 20;
                etiquetaProgreso.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                etiquetaProgreso.Text = "Iniciando...";

                barra = new ProgressBar();
                barra.Dock = DockStyle.Bottom;
                barra.Height = 22;
                barra.Minimum = 0;
                barra.Maximum = totalLineas;
                barra.Value = 0;

                this.Controls.Add(etiquetaProgreso);
                this.Controls.Add(barra);
                barra.BringToFront();

                // Con simulación el await refresca la interfaz solo; sin espera se actualiza cada cierto número de líneas
                int pasoProgreso = segundosPorHora > 0 ? 1 : 200;

                // ---------- Niveles actuales de las 4 métricas (los llena la lectura; los usa la ventana de información) ----------
                double[] nivelActual = { double.NaN, double.NaN, double.NaN, double.NaN };   // mediana de las últimas lecturas
                double[] nivelNormal = { double.NaN, double.NaN, double.NaN, double.NaN };   // valor normal visto hasta ahora
                bool[] nivelElevado = new bool[4];                                           // ¿supera el margen de alerta?

                // ---------- Funciones auxiliares ----------
                // Eventos del contexto: respaldo diario 03:00 (30 min), reindexado de domingo 04:00 (90 min)
                // y campana del viernes 9 de octubre 12:00 (2 h). "cola" = minutos extra después de cada evento
                Func<DateTime, int, bool> esEventoEsperado = (fecha, cola) =>
                {
                    int minutosDelDia = fecha.Hour * 60 + fecha.Minute;
                    if (minutosDelDia >= 180 && minutosDelDia < 210 + cola) return true;
                    if (fecha.DayOfWeek == DayOfWeek.Sunday && minutosDelDia >= 240 && minutosDelDia < 330 + cola) return true;
                    if (fecha.Date == new DateTime(2026, 10, 9) && minutosDelDia >= 720 && minutosDelDia < 840 + cola) return true;
                    return false;
                };

                // Ventana crítica de la tienda en línea (fuente "app"): campanas y fines de semana.
                // Dentro de ella sus errores se esperan por la alta demanda; servidor y firewall son 24/7 (nunca se descartan)
                Func<string, DateTime, bool> errorEsperadoPorVentana = (fuenteDelLog, fecha) =>
                {
                    if (fuenteDelLog.Trim().Equals("app", StringComparison.OrdinalIgnoreCase))
                    {
                        bool finDeSemana = fecha.DayOfWeek == DayOfWeek.Saturday || fecha.DayOfWeek == DayOfWeek.Sunday;
                        bool campana = fecha.Date == new DateTime(2026, 10, 9) &&
                                       fecha.TimeOfDay >= new TimeSpan(12, 0, 0) && fecha.TimeOfDay < new TimeSpan(14, 0, 0);
                        return finDeSemana || campana;
                    }
                    return false;
                };

                // Riesgo conocido: el checkout no tiene límite de conexiones por cliente
                // (el log del checkout menciona una cantidad de peticiones, ej. "14 peticiones")
                Func<string, bool> esRiesgoConocido = texto =>
                    texto.IndexOf("checkout", StringComparison.OrdinalIgnoreCase) >= 0 &&
                    System.Text.RegularExpressions.Regex.IsMatch(texto, @"\d+\s+peticiones",
                        System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                // Log WARN de saturación que sirve como evidencia de que un error puede venir
                Func<string, string, bool> esEvidencia = (nivelDelLog, mensajeDelLog) =>
                    nivelDelLog.Equals("WARN", StringComparison.OrdinalIgnoreCase) &&
                    Array.Exists(palabrasEvidencia, palabra => mensajeDelLog.IndexOf(palabra, StringComparison.OrdinalIgnoreCase) >= 0) &&
                    !Array.Exists(palabrasExcluidas, palabra => mensajeDelLog.IndexOf(palabra, StringComparison.OrdinalIgnoreCase) >= 0);

                // Mediana de una lista YA ordenada
                Func<System.Collections.Generic.List<double>, double> medianaOrdenada = valores =>
                {
                    int cuenta = valores.Count;
                    return cuenta % 2 == 1 ? valores[cuenta / 2] : (valores[cuenta / 2 - 1] + valores[cuenta / 2]) / 2.0;
                };

                Func<string, string> entreComillas = texto => "\"" + texto.Replace("\"", "\"\"") + "\"";
                Func<double, string> formatoTiempo = minutos =>
                    minutos < 120 ? minutos.ToString("0") + " min" : (minutos / 60.0).ToString("0.0") + " h";

                // ---------- Ventana con botones personalizados (un MessageBox no permite botones propios) ----------
                // Devuelve la posición del botón presionado (0 = el primero, 1 = el segundo...) o -1 si se cierra con la X
                Func<string, string, string[], int> mostrarDialogo = (tituloVentana, textoVentana, textosBotones) =>
                {
                    int resultado = -1;

                    using (Form ventana = new Form())
                    {
                        ventana.Text = tituloVentana;
                        ventana.FormBorderStyle = FormBorderStyle.FixedDialog;
                        ventana.StartPosition = FormStartPosition.CenterParent;
                        ventana.MaximizeBox = false;
                        ventana.MinimizeBox = false;
                        ventana.ShowInTaskbar = false;
                        ventana.Font = System.Drawing.SystemFonts.MessageBoxFont;

                        Panel panelTexto = new Panel();
                        panelTexto.Dock = DockStyle.Fill;
                        panelTexto.AutoScroll = true;
                        panelTexto.BackColor = System.Drawing.Color.White;

                        Label etiquetaTexto = new Label();
                        etiquetaTexto.AutoSize = true;
                        etiquetaTexto.MaximumSize = new System.Drawing.Size(580, 0);
                        etiquetaTexto.Text = textoVentana;
                        etiquetaTexto.Location = new System.Drawing.Point(16, 16);
                        panelTexto.Controls.Add(etiquetaTexto);

                        FlowLayoutPanel panelBotones = new FlowLayoutPanel();
                        panelBotones.Dock = DockStyle.Bottom;
                        panelBotones.Height = 52;
                        panelBotones.FlowDirection = FlowDirection.RightToLeft;
                        panelBotones.Padding = new Padding(8);

                        // Primero el panel que rellena y después el de abajo
                        ventana.Controls.Add(panelTexto);
                        ventana.Controls.Add(panelBotones);

                        // Con RightToLeft el primero que se agrega queda a la derecha; se agregan al revés
                        // para que el orden visual sea el mismo que el del arreglo
                        for (int n = textosBotones.Length - 1; n >= 0; n--)
                        {
                            int indiceBoton = n;
                            Button botonVentana = new Button();
                            botonVentana.Text = textosBotones[n];
                            botonVentana.AutoSize = true;
                            botonVentana.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                            botonVentana.MinimumSize = new System.Drawing.Size(100, 32);
                            botonVentana.Padding = new Padding(8, 2, 8, 2);
                            botonVentana.Click += (origen, argumentos) =>
                            {
                                resultado = indiceBoton;
                                ventana.Close();
                            };
                            panelBotones.Controls.Add(botonVentana);
                        }

                        int altoTexto = etiquetaTexto.GetPreferredSize(new System.Drawing.Size(580, 0)).Height + 40;
                        ventana.ClientSize = new System.Drawing.Size(640, Math.Min(altoTexto, 520) + panelBotones.Height);

                        ventana.ShowDialog(this);
                    }

                    return resultado;
                };

                // ---------- Texto de "Información del problema" ----------
                // Descripción del error previsto, niveles de CPU/RAM/Disco/Latencia y acciones recomendadas
                Func<DateTime, string, string> construirInformacion = (momentoAlerta, evidenciaAlerta) =>
                {
                    string evidenciaMinusculas = (evidenciaAlerta ?? "").ToLowerInvariant();

                    // Qué se está saturando (según los logs y las métricas elevadas)
                    string queOcurre;
                    if (evidenciaMinusculas.Contains("pool de conexiones") || evidenciaMinusculas.Contains("pico de conexiones"))
                        queOcurre = "Se están agotando las conexiones disponibles: llegan demasiadas peticiones a la vez y el pool de conexiones se satura.";
                    else if (evidenciaMinusculas.Contains("memoria") || evidenciaMinusculas.Contains("ram de "))
                        queOcurre = "Se está agotando la memoria del sistema.";
                    else if (evidenciaMinusculas.Contains("cpu de "))
                        queOcurre = "El procesador está trabajando al límite.";
                    else if (evidenciaMinusculas.Contains("latencia"))
                        queOcurre = "Las respuestas del sistema se están volviendo cada vez más lentas.";
                    else
                        queOcurre = "El sistema se está saturando.";

                    System.Text.StringBuilder sb = new System.Text.StringBuilder();
                    sb.AppendLine("DESCRIPCIÓN DEL PROBLEMA");
                    sb.AppendLine();
                    sb.AppendLine(queOcurre);
                    sb.AppendLine("Varias métricas están por encima de su nivel normal al mismo tiempo y los logs ya registraron un aviso de saturación. " +
                                  "Si no se actúa, es muy probable que ocurra un error en los próximos minutos.");
                    sb.AppendLine();
                    sb.AppendLine("Hora de la lectura: " + momentoAlerta.ToString("yyyy-MM-dd HH:mm:ss"));
                    sb.AppendLine("Aviso en los logs: " + evidenciaAlerta);
                    sb.AppendLine();
                    sb.AppendLine("NIVELES DE LAS MÉTRICAS");
                    sb.AppendLine();

                    for (int m = 0; m < 4; m++)
                    {
                        string linea1;
                        if (double.IsNaN(nivelActual[m]) || double.IsNaN(nivelNormal[m]))
                        {
                            linea1 = nombres[m] + ": sin datos suficientes";
                        }
                        else
                        {
                            linea1 = nombres[m] + ": " + nivelActual[m].ToString("0.0") + unidades[m] +
                                     "   (normal " + nivelNormal[m].ToString("0.0") + unidades[m] +
                                     ", límite de alerta " + (nivelNormal[m] + margenes[m]).ToString("0.0") + unidades[m] + ")" +
                                     (nivelElevado[m] ? "   <-- PREOCUPANTE" : "   (normal)");
                        }
                        sb.AppendLine("   " + linea1);
                    }

                    // Acciones recomendadas (sin repetir)
                    System.Collections.Generic.List<string> acciones = new System.Collections.Generic.List<string>();

                    if (evidenciaMinusculas.Contains("pool de conexiones") || evidenciaMinusculas.Contains("pico de conexiones"))
                    {
                        acciones.Add("Poner un límite de conexiones/peticiones por cliente (en especial en el checkout).");
                        acciones.Add("Aumentar el tamaño del pool de conexiones y asegurarse de cerrar siempre las conexiones.");
                    }
                    if (nivelElevado[0])
                        acciones.Add("CPU: identificar el proceso que más consume y optimizarlo o detenerlo; mover tareas pesadas a horarios de baja demanda.");
                    if (nivelElevado[1])
                        acciones.Add("RAM: liberar memoria (reiniciar el servicio con fuga, vaciar cachés) y revisar procesos que cargan datos completos en memoria.");
                    if (nivelElevado[2])
                        acciones.Add("Disco: liberar espacio (logs viejos, temporales, respaldos antiguos) y reducir escrituras innecesarias.");
                    if (nivelElevado[3])
                        acciones.Add("Latencia: revisar la red y las consultas lentas a la base de datos; activar caché para lo que se consulta seguido.");
                    acciones.Add("Repartir la carga entre más servidores (balanceador) o aumentar los recursos del servidor afectado.");
                    acciones.Add("Vigilar CPU, RAM, disco y latencia durante los próximos minutos hasta que vuelvan a su nivel normal.");

                    sb.AppendLine();
                    sb.AppendLine("ACCIONES RECOMENDADAS PARA EVITAR EL ERROR");
                    sb.AppendLine();
                    for (int p = 0; p < acciones.Count; p++)
                        sb.AppendLine("   " + (p + 1) + ". " + acciones[p]);

                    sb.AppendLine();
                    sb.AppendLine("¿QUÉ HACE CADA BOTÓN?");
                    sb.AppendLine("   Tomar acción: se aplica la solución y el error de esta alarma desaparece (se evita).");
                    sb.AppendLine("   Ignorar: no se hace nada y el error podría ocurrir.");
                    sb.AppendLine("En ambos casos la lectura continúa al presionar el botón.");

                    return sb.ToString();
                };

                // ---------- Cargar los logs (formato: "2026-10-08T09:38:20 NIVEL mensaje") ----------
                // Cada log: fecha, fuente (la sección "## servidor", "## firewall", "## app"), nivel y mensaje.
                // Se cargan completos, pero durante la lectura solo se "ven" los que tienen hora <= la de la línea actual
                System.Collections.Generic.List<Tuple<DateTime, string, string, string>> logs =
                    new System.Collections.Generic.List<Tuple<DateTime, string, string, string>>();
                string fuenteLog = "";

                foreach (string lineaLog in System.IO.File.ReadLines(rutaLogs, System.Text.Encoding.UTF8))
                {
                    if (lineaLog.StartsWith("## "))
                    {
                        fuenteLog = lineaLog.Substring(3).Trim();
                        continue;
                    }

                    if (lineaLog.Length < 21)
                        continue;

                    if (!DateTime.TryParseExact(lineaLog.Substring(0, 19), "yyyy-MM-ddTHH:mm:ss",
                            System.Globalization.CultureInfo.InvariantCulture,
                            System.Globalization.DateTimeStyles.None, out DateTime fechaLog))
                        continue;

                    string resto = lineaLog.Substring(20).Trim();
                    int espacio = resto.IndexOf(' ');
                    string nivel = espacio > 0 ? resto.Substring(0, espacio) : resto;
                    string mensaje = espacio > 0 ? resto.Substring(espacio + 1) : "";

                    logs.Add(Tuple.Create(fechaLog, fuenteLog, nivel, mensaje));
                }

                // Ordena todos los logs por fecha y hora (estable: en empates conserva el orden del archivo)
                logs = System.Linq.Enumerable.ToList(System.Linq.Enumerable.OrderBy(logs, registro => registro.Item1));

                // ---------- Estado de las alarmas (una por episodio) ----------
                System.Collections.Generic.List<DateTime> candDisparo = new System.Collections.Generic.List<DateTime>();   // cuando las métricas la detectaron
                System.Collections.Generic.List<DateTime> candFin = new System.Collections.Generic.List<DateTime>();       // fin del episodio
                System.Collections.Generic.List<bool> candVisible = new System.Collections.Generic.List<bool>();           // ¿se mostró?
                System.Collections.Generic.List<DateTime> candMostradaEn = new System.Collections.Generic.List<DateTime>(); // cuando se mostró
                System.Collections.Generic.List<int> candLinea = new System.Collections.Generic.List<int>();
                System.Collections.Generic.List<string> candMetricas = new System.Collections.Generic.List<string>();
                System.Collections.Generic.List<string> candEvidencia = new System.Collections.Generic.List<string>();
                System.Collections.Generic.List<bool> candAtendida = new System.Collections.Generic.List<bool>();           // ¿el usuario presionó "Tomar acción"?
                System.Collections.Generic.List<int> candEvitados = new System.Collections.Generic.List<int>();             // errores que desaparecieron por esa acción
                int candActual = -1;

                // ---------- Estado de los errores confirmados en tiempo real ----------
                System.Collections.Generic.List<int> confLog = new System.Collections.Generic.List<int>();           // posición en "logs"
                System.Collections.Generic.List<DateTime> confTiempo = new System.Collections.Generic.List<DateTime>(); // fila del CSV
                System.Collections.Generic.HashSet<int> logsConfirmados = new System.Collections.Generic.HashSet<int>();

                int lineasLeidas = 0;
                int filasConError = 0;
                int accionesTomadas = 0;     // veces que se presionó "Tomar acción"
                int erroresEvitados = 0;     // filas con error que desaparecieron por una acción tomada

                // =====================================================================
                // LECTURA EN TIEMPO REAL
                // =====================================================================
                using (System.IO.StreamReader lector = new System.IO.StreamReader(ruta, System.Text.Encoding.UTF8, true))
                using (System.IO.StreamWriter escritorErrores = new System.IO.StreamWriter(rutaConErrores, false, new System.Text.UTF8Encoding(true)))
                using (System.IO.StreamWriter escritorConfirmados = new System.IO.StreamWriter(rutaConfirmados, false, new System.Text.UTF8Encoding(true)))
                {
                    // ---------- Encabezado ----------
                    string encabezado = lector.ReadLine();
                    if (string.IsNullOrWhiteSpace(encabezado))
                    {
                        MessageBox.Show("El archivo está vacío.");
                        return;
                    }

                    char separador = ',';
                    if (encabezado.Split(';').Length > encabezado.Split(separador).Length) separador = ';';
                    if (encabezado.Split('\t').Length > encabezado.Split(separador).Length) separador = '\t';

                    string[] columnas = encabezado.Split(separador);
                    Func<string, int> buscar = prefijo => Array.FindIndex(columnas,
                        nombreColumna => nombreColumna.Trim().Trim('"').StartsWith(prefijo, StringComparison.OrdinalIgnoreCase));

                    int idxFecha = buscar("timestamp");
                    int idxErrores = buscar("errores");
                    int[] idxMetrica = { buscar("cpu"), buscar("ram"), buscar("disco"), buscar("latencia") };

                    if (idxFecha < 0 || idxErrores < 0 || Array.IndexOf(idxMetrica, -1) >= 0)
                    {
                        MessageBox.Show("El archivo debe tener las columnas: timestamp, cpu, ram, disco, latencia y errores.");
                        return;
                    }

                    escritorErrores.WriteLine(encabezado);
                    escritorConfirmados.WriteLine("grupo,rol,timestamp_log,fuente,nivel,mensaje,timestamp_csv,errores_csv");

                    // ---------- Estado de la lectura (solo datos pasados) ----------
                    // Todos los valores válidos leídos hasta ahora (ordenados) -> valor normal = su mediana
                    System.Collections.Generic.List<double>[] historial = new System.Collections.Generic.List<double>[4];
                    // Últimas lecturas (NaN si estaba vacía) -> mediana móvil
                    System.Collections.Generic.List<double>[] ultimas = new System.Collections.Generic.List<double>[4];
                    for (int j = 0; j < 4; j++)
                    {
                        historial[j] = new System.Collections.Generic.List<double>();
                        ultimas[j] = new System.Collections.Generic.List<double>();
                    }

                    int consecutivas = 0;
                    bool alarmaActiva = false;
                    DateTime? ultimaCondicion = null;

                    // Logs ya "vistos": todos los que tienen hora <= la de la línea actual
                    int punteroLogs = 0;
                    // Horas y textos de los logs de evidencia ya vistos (en orden cronológico)
                    System.Collections.Generic.List<DateTime> evidenciaHora = new System.Collections.Generic.List<DateTime>();
                    System.Collections.Generic.List<string> evidenciaTexto = new System.Collections.Generic.List<string>();

                    // Reloj de la simulación: se reinicia después de cada ventana de alarma para no "recuperar" el tiempo en pausa
                    System.Diagnostics.Stopwatch reloj = new System.Diagnostics.Stopwatch();
                    DateTime? momentoReferencia = null;

                    string linea;
                    while ((linea = lector.ReadLine()) != null)
                    {
                        if (string.IsNullOrWhiteSpace(linea))
                            continue;

                        string[] campos = linea.Split(separador);
                        if (idxFecha >= campos.Length)
                            continue;

                        if (!DateTime.TryParse(campos[idxFecha].Trim().Trim('"'),
                                System.Globalization.CultureInfo.InvariantCulture,
                                System.Globalization.DateTimeStyles.None, out DateTime momento))
                            continue;

                        lineasLeidas++;
                        DateTime momentoMinuto = new DateTime(momento.Year, momento.Month, momento.Day, momento.Hour, momento.Minute, 0);

                        // ---------- Simulación del paso del tiempo ----------
                        if (segundosPorHora > 0)
                        {
                            if (!momentoReferencia.HasValue)
                            {
                                momentoReferencia = momento;
                                reloj.Restart();
                            }

                            double objetivoMs = (momento - momentoReferencia.Value).TotalHours * segundosPorHora * 1000.0;
                            double espera = objetivoMs - reloj.ElapsedMilliseconds;
                            if (espera >= 1)
                                await System.Threading.Tasks.Task.Delay((int)espera);
                        }

                        this.Text = "Simulando: " + momento.ToString("yyyy-MM-dd HH:mm") +
                                    "   |   Alarmas: " + candDisparo.Count + "   |   Errores confirmados: " + confLog.Count +
                                    "   |   Acciones tomadas: " + accionesTomadas + "   |   Errores evitados: " + erroresEvitados;

                        // ---------- Progreso (líneas leídas y tiempo simulado) ----------
                        if (lineasLeidas % pasoProgreso == 0)
                        {
                            barra.Value = Math.Min(lineasLeidas, barra.Maximum);
                            etiquetaProgreso.Text = (100.0 * lineasLeidas / totalLineas).ToString("0.0") + " %   |   " +
                                                    lineasLeidas + " de " + totalLineas + " líneas   |   " +
                                                    momento.ToString("yyyy-MM-dd HH:mm");
                            if (segundosPorHora <= 0)
                                Application.DoEvents(); // sin espera no hay await, así que se refresca la interfaz a mano
                        }

                        // ---------- A) Leer los logs hasta la hora de esta línea (nunca los futuros) ----------
                        while (punteroLogs < logs.Count && logs[punteroLogs].Item1 <= momento)
                        {
                            Tuple<DateTime, string, string, string> visto = logs[punteroLogs];
                            if (esEvidencia(visto.Item3, visto.Item4))
                            {
                                evidenciaHora.Add(visto.Item1);
                                evidenciaTexto.Add(visto.Item1.ToString("HH:mm:ss") + " " + visto.Item2 + ": " + visto.Item4);
                            }
                            punteroLogs++;
                        }

                        // ---------- B) Filas con errores >= 1 (lo que hacía el primer botón) ----------
                        bool filaConErrores =
                            idxErrores < campos.Length &&
                            decimal.TryParse(campos[idxErrores].Trim(), System.Globalization.NumberStyles.Any,
                                             System.Globalization.CultureInfo.InvariantCulture, out decimal cantidadErrores) &&
                            cantidadErrores >= 1;

                        // Si el usuario ya presionó "Tomar acción" en la alarma activa, los errores de ese episodio desaparecen
                        bool errorEvitado = filaConErrores && candActual >= 0 && candAtendida[candActual] &&
                                            momento <= candFin[candActual].AddMinutes(minutosToleranciaFin);

                        if (filaConErrores && errorEvitado)
                        {
                            // El error no se registra ni se confirma: se evitó con la acción tomada
                            erroresEvitados++;
                            candEvitados[candActual]++;
                        }
                        else if (filaConErrores)
                        {
                            filasConError++;
                            escritorErrores.WriteLine(linea);

                            // ---------- C) Confirmar errores verdaderos: log ERROR 1 o 2 minutos antes de esta fila ----------
                            for (int k = punteroLogs - 1; k >= 0; k--)
                            {
                                Tuple<DateTime, string, string, string> registro = logs[k];
                                DateTime minutoLog = new DateTime(registro.Item1.Year, registro.Item1.Month, registro.Item1.Day,
                                                                  registro.Item1.Hour, registro.Item1.Minute, 0);

                                if (minutoLog < momentoMinuto.AddMinutes(-2))
                                    break; // los logs más viejos ya no pueden corresponder a esta fila

                                if (logsConfirmados.Contains(k))
                                    continue;

                                if (!registro.Item3.Equals("ERROR", StringComparison.OrdinalIgnoreCase))
                                    continue;

                                // "(reintento N s)": no es un error en sí
                                if (System.Text.RegularExpressions.Regex.IsMatch(registro.Item4, @"\(\s*reintento\s+\d+\s*s\s*\)",
                                        System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                                    continue;

                                int diferenciaMinutos = (int)(momentoMinuto - minutoLog).TotalMinutes;
                                if (Array.IndexOf(desfasesMetrica, diferenciaMinutos) < 0)
                                    continue;

                                // Evento esperado del contexto (respaldo, reindexado, campana)
                                if (esEventoEsperado(registro.Item1, 0))
                                    continue;

                                // Riesgo conocido: se conserva siempre. Si no lo es, se descarta lo esperado por la
                                // ventana crítica de la tienda o por tener el reintento ya programado
                                if (!esRiesgoConocido(registro.Item4))
                                {
                                    if (errorEsperadoPorVentana(registro.Item2, registro.Item1))
                                        continue;
                                    if (registro.Item4.IndexOf("reintento programado", StringComparison.OrdinalIgnoreCase) >= 0)
                                        continue;
                                }

                                // Error confirmado: se guarda con sus logs anteriores
                                logsConfirmados.Add(k);
                                confLog.Add(k);
                                confTiempo.Add(momentoMinuto);

                                for (int antes = logsAnteriores; antes >= 0; antes--)
                                {
                                    int posicion = k - antes;
                                    if (posicion < 0)
                                        continue;

                                    Tuple<DateTime, string, string, string> anterior = logs[posicion];
                                    string rol = antes == 0 ? "ERROR CONFIRMADO" : "Anterior " + antes;

                                    escritorConfirmados.WriteLine(string.Join(",",
                                        confLog.Count,
                                        rol,
                                        anterior.Item1.ToString("yyyy-MM-ddTHH:mm:ss"),
                                        entreComillas(anterior.Item2),
                                        anterior.Item3,
                                        entreComillas(anterior.Item4),
                                        momentoMinuto.ToString("yyyy-MM-ddTHH:mm:ss"),
                                        campos[idxErrores].Trim()));
                                }
                            }
                        }

                        // ---------- D) Lee las 4 métricas de esta línea (vacío = NaN) y actualiza el historial ----------
                        for (int j = 0; j < 4; j++)
                        {
                            // Si la celda está vacía o no es un número, queda como NaN (lectura faltante)
                            double valor = double.NaN;
                            if (idxMetrica[j] < campos.Length &&
                                !double.TryParse(campos[idxMetrica[j]].Trim().Trim('"'),
                                    System.Globalization.NumberStyles.Float,
                                    System.Globalization.CultureInfo.InvariantCulture, out valor))
                            {
                                valor = double.NaN;
                            }

                            if (!double.IsNaN(valor))
                            {
                                int pos = historial[j].BinarySearch(valor);
                                if (pos < 0) pos = ~pos;
                                historial[j].Insert(pos, valor);
                            }

                            ultimas[j].Add(valor);
                            if (ultimas[j].Count > lecturasMediana)
                                ultimas[j].RemoveAt(0);
                        }

                        // Mientras no haya suficientes lecturas para conocer el valor normal, solo se aprende
                        if (historial[0].Count < lecturasCalentamiento)
                            continue;

                        // ---------- E) ¿Cuántas métricas están elevadas ahora? ----------
                        int elevadas = 0;
                        System.Collections.Generic.List<string> detalle = new System.Collections.Generic.List<string>();

                        for (int j = 0; j < 4; j++)
                        {
                            // Se reinician los niveles de esta métrica; se llenan si hay datos suficientes
                            nivelActual[j] = double.NaN;
                            nivelNormal[j] = double.NaN;
                            nivelElevado[j] = false;

                            System.Collections.Generic.List<double> validas = new System.Collections.Generic.List<double>();
                            foreach (double lectura in ultimas[j])
                                if (!double.IsNaN(lectura)) validas.Add(lectura);

                            if (validas.Count < minimoLecturasValidas || historial[j].Count == 0)
                                continue;

                            validas.Sort();
                            double actual = medianaOrdenada(validas);       // mediana de las últimas lecturas
                            double normal = medianaOrdenada(historial[j]);  // valor normal visto hasta ahora

                            nivelActual[j] = actual;
                            nivelNormal[j] = normal;

                            if (actual > normal + margenes[j])
                            {
                                nivelElevado[j] = true;
                                elevadas++;
                                detalle.Add(nombres[j] + ": " + actual.ToString("0.0") + unidades[j] +
                                            " (normal " + normal.ToString("0.0") + unidades[j] +
                                            ", +" + (actual - normal).ToString("0.0") + ")");
                            }
                        }

                        bool condicion = elevadas >= metricasMinimas;

                        // Durante un evento esperado no se alerta
                        if (silenciarEventosEsperados && esEventoEsperado(momento, minutosColaEvento))
                        {
                            condicion = false;
                            consecutivas = 0;
                        }

                        if (condicion)
                        {
                            ultimaCondicion = momento;
                            consecutivas++;
                        }
                        else
                        {
                            consecutivas = 0;
                        }

                        // La alarma se rearma si pasó mucho tiempo sin la condición
                        if (alarmaActiva && ultimaCondicion.HasValue &&
                            (momento - ultimaCondicion.Value).TotalMinutes > minutosParaRearmar)
                        {
                            alarmaActiva = false;
                            candActual = -1;
                        }

                        // Las métricas detectan un posible error: se crea la alarma (todavía no se muestra)
                        if (!alarmaActiva && consecutivas >= persistencia)
                        {
                            alarmaActiva = true;
                            candDisparo.Add(momento);
                            candFin.Add(momento);
                            candVisible.Add(false);
                            candMostradaEn.Add(momento);
                            candLinea.Add(lineasLeidas + 1);
                            candMetricas.Add(string.Join(" | ", detalle));
                            candEvidencia.Add("");
                            candAtendida.Add(false);
                            candEvitados.Add(0);
                            candActual = candDisparo.Count - 1;
                        }

                        // Mientras la alarma está activa se va extendiendo el fin del episodio
                        if (alarmaActiva && ultimaCondicion.HasValue && candActual >= 0)
                            candFin[candActual] = ultimaCondicion.Value;

                        // ---------- F) ¿Se muestra la alarma o se predice que es falsa? ----------
                        if (alarmaActiva && candActual >= 0 && !candVisible[candActual])
                        {
                            string evidencia = null;

                            if (!exigirEvidenciaEnLogs)
                            {
                                evidencia = "(sin validar con logs)";
                            }
                            else if (ultimaCondicion.HasValue &&
                                     (momento - ultimaCondicion.Value).TotalMinutes <= minutosCondicionReciente &&
                                     evidenciaHora.Count > 0 &&
                                     (momento - evidenciaHora[evidenciaHora.Count - 1]).TotalMinutes <= minutosEvidenciaLogs)
                            {
                                // Hay un aviso WARN de saturación reciente en los logs ya leídos
                                evidencia = evidenciaTexto[evidenciaTexto.Count - 1];
                            }

                            if (evidencia != null)
                            {
                                candVisible[candActual] = true;
                                candMostradaEn[candActual] = momento;
                                candEvidencia[candActual] = evidencia;

                                string metricasAhora = detalle.Count > 0
                                    ? string.Join("\n", detalle)
                                    : candMetricas[candActual].Replace(" | ", "\n");

                                string textoAlerta =
                                    "Se predice que va a ocurrir un error.\n\n" +
                                    "Hora de la lectura: " + momento.ToString("yyyy-MM-dd HH:mm:ss") + "\n" +
                                    "Línea del archivo: " + (lineasLeidas + 1) + "\n\n" +
                                    "Métricas elevadas:\n" + metricasAhora + "\n\n" +
                                    "Evidencia en los logs:\n" + evidencia + "\n\n" +
                                    "Presiona \"Información del problema\" para ver el detalle y las acciones recomendadas.\n" +
                                    "La lectura continuará al cerrar este mensaje.";

                                // Alarma con dos botones: Aceptar / Información del problema
                                int respuesta = mostrarDialogo("Alerta: posible error próximo", textoAlerta,
                                    new string[] { "Aceptar", "Información del problema" });

                                if (respuesta == 1)
                                {
                                    // Segunda ventana: descripción, niveles, acciones recomendadas y decisión del usuario
                                    int decision = mostrarDialogo("Información del problema",
                                        construirInformacion(momento, evidencia),
                                        new string[] { "Tomar acción", "Ignorar" });

                                    if (decision == 0)
                                    {
                                        // Tomar acción: el error de esta alarma desaparece (sus filas con error se omitirán)
                                        candAtendida[candActual] = true;
                                        accionesTomadas++;
                                    }
                                    // Ignorar (o cerrar con la X): no se hace nada
                                }
                                // El código no sigue leyendo hasta que se cierran las ventanas

                                // El tiempo que estuvo pausado no cuenta para la simulación
                                momentoReferencia = momento;
                                reloj.Restart();
                            }
                            // Si no hay evidencia, la alarma sigue "en espera": si el episodio termina sin evidencia,
                            // se descarta como falsa alarma y nunca se muestra
                        }
                    }
                }

                this.Text = tituloOriginal;

                // Lectura terminada: la barra queda al 100 %
                barra.Value = barra.Maximum;
                etiquetaProgreso.Text = "100 %   |   Lectura completada";

                // =====================================================================
                // COMPARACIÓN FINAL: alertas vs errores confirmados
                // =====================================================================
                int totalAlarmas = candDisparo.Count;
                int[] alertaDelError = new int[confLog.Count];       // alerta mostrada que cubre a cada error confirmado
                int[] errorDeLaAlarma = new int[totalAlarmas];       // error confirmado que cubre cada alarma
                for (int g = 0; g < confLog.Count; g++)
                    alertaDelError[g] = -1;
                for (int a = 0; a < totalAlarmas; a++)
                    errorDeLaAlarma[a] = -1;

                for (int a = 0; a < totalAlarmas; a++)
                {
                    // Una alerta mostrada cubre errores desde que se mostró; una descartada, desde que se detectó
                    DateTime desde = candVisible[a] ? candMostradaEn[a] : candDisparo[a];
                    DateTime hasta = candFin[a].AddMinutes(minutosToleranciaFin);

                    for (int g = 0; g < confLog.Count; g++)
                    {
                        if (confTiempo[g] >= desde && confTiempo[g] <= hasta)
                        {
                            if (errorDeLaAlarma[a] < 0)
                                errorDeLaAlarma[a] = g;
                            if (candVisible[a] && alertaDelError[g] < 0)
                                alertaDelError[g] = a;
                        }
                    }
                }

                System.Collections.Generic.List<string> resumenConfirmadas = new System.Collections.Generic.List<string>();
                System.Collections.Generic.List<string> resumenAtendidas = new System.Collections.Generic.List<string>();
                System.Collections.Generic.List<string> resumenFalsas = new System.Collections.Generic.List<string>();
                System.Collections.Generic.List<string> resumenEquivocadas = new System.Collections.Generic.List<string>();
                System.Collections.Generic.List<string> resumenSinAlerta = new System.Collections.Generic.List<string>();
                int mostradas = 0, confirmadas = 0, atendidas = 0, atendidasEvitado = 0, falsasMostradas = 0,
                    descartadas = 0, descartadasBien = 0, descartadasMal = 0, sinAlerta = 0;

                using (System.IO.StreamWriter escritorValidadas = new System.IO.StreamWriter(rutaValidadas, false, new System.Text.UTF8Encoding(true)))
                {
                    escritorValidadas.WriteLine("tipo,n,hora_disparo,hora_mostrada,fin_episodio,linea_csv,metricas_elevadas,evidencia_logs,hora_error_confirmado,mensaje_error,anticipacion_min,errores_evitados");

                    for (int a = 0; a < totalAlarmas; a++)
                    {
                        string disparo = candDisparo[a].ToString("yyyy-MM-dd HH:mm");
                        string fin = candFin[a].ToString("yyyy-MM-dd HH:mm");
                        int g = errorDeLaAlarma[a];
                        string horaError = g >= 0 ? confTiempo[g].ToString("yyyy-MM-dd HH:mm") : "";
                        string mensajeError = g >= 0 ? entreComillas(logs[confLog[g]].Item4) : "";
                        string evitadosTexto = candAtendida[a] ? candEvitados[a].ToString() : "";

                        string tipo;
                        string anticipacion = "";

                        if (candVisible[a])
                        {
                            mostradas++;
                            if (candAtendida[a])
                            {
                                // El usuario presionó "Tomar acción" en esta alarma
                                atendidas++;
                                if (candEvitados[a] > 0)
                                {
                                    tipo = "ALERTA ATENDIDA - ERROR EVITADO";
                                    atendidasEvitado++;
                                    resumenAtendidas.Add("alerta " + candMostradaEn[a].ToString("yyyy-MM-dd HH:mm") +
                                        "  (acción tomada; errores evitados: " + candEvitados[a] + ")");
                                }
                                else
                                {
                                    tipo = "ALERTA ATENDIDA - SIN ERROR DESPUES";
                                    resumenAtendidas.Add("alerta " + candMostradaEn[a].ToString("yyyy-MM-dd HH:mm") +
                                        "  (acción tomada; no hubo errores después)");
                                }
                            }
                            else if (g >= 0)
                            {
                                tipo = "ALERTA CONFIRMADA";
                                confirmadas++;
                                double minutosAntes = (confTiempo[g] - candMostradaEn[a]).TotalMinutes;
                                anticipacion = minutosAntes.ToString("0");
                                resumenConfirmadas.Add("alerta " + candMostradaEn[a].ToString("yyyy-MM-dd HH:mm") + "  ->  error " +
                                    horaError + " (" + formatoTiempo(minutosAntes) + " antes)");
                            }
                            else
                            {
                                tipo = "FALSA ALARMA MOSTRADA";
                                falsasMostradas++;
                                resumenFalsas.Add(candMostradaEn[a].ToString("yyyy-MM-dd HH:mm") + "  (se mostró, pero no hubo error)");
                            }
                        }
                        else
                        {
                            descartadas++;
                            if (g >= 0)
                            {
                                tipo = "ALARMA DESCARTADA QUE SI ERA ERROR";
                                descartadasMal++;
                                resumenEquivocadas.Add(disparo + "  (error confirmado a las " + horaError + ")");
                            }
                            else
                            {
                                tipo = "FALSA ALARMA DESCARTADA";
                                descartadasBien++;
                                resumenFalsas.Add(disparo + "  (no se mostró; episodio hasta " + candFin[a].ToString("HH:mm") + ")");
                            }
                        }

                        escritorValidadas.WriteLine(string.Join(",", new string[] {
                            tipo,
                            (a + 1).ToString(),
                            disparo,
                            candVisible[a] ? candMostradaEn[a].ToString("yyyy-MM-dd HH:mm") : "",
                            fin,
                            candLinea[a].ToString(),
                            entreComillas(candMetricas[a]),
                            entreComillas(candEvidencia[a]),
                            horaError,
                            mensajeError,
                            anticipacion,
                            evitadosTexto }));
                    }

                    // Errores confirmados que ninguna alerta mostrada predijo
                    for (int g = 0; g < confLog.Count; g++)
                    {
                        if (alertaDelError[g] >= 0)
                            continue;

                        sinAlerta++;
                        string horaSinAlerta = confTiempo[g].ToString("yyyy-MM-dd HH:mm");
                        escritorValidadas.WriteLine(string.Join(",", new string[] {
                            "ERROR CONFIRMADO SIN ALERTA", sinAlerta.ToString(), "", "", "", "", "", "",
                            horaSinAlerta, entreComillas(logs[confLog[g]].Item4), "", "" }));
                        resumenSinAlerta.Add(horaSinAlerta + "  (" + logs[confLog[g]].Item2 + ")");
                    }
                }

                // ---------- Resumen final ----------
                Func<System.Collections.Generic.List<string>, string> primeras = lista =>
                {
                    if (lista.Count == 0) return "   (ninguna)";
                    int maximo = Math.Min(lista.Count, 12);
                    string texto = "   " + string.Join("\n   ", lista.GetRange(0, maximo));
                    if (lista.Count > maximo) texto += "\n   ... y " + (lista.Count - maximo) + " más (ver el archivo)";
                    return texto;
                };

                MessageBox.Show(
                    "Líneas leídas: " + lineasLeidas + " (filas con errores: " + filasConError + ")\n" +
                    "Errores confirmados (con logs): " + confLog.Count + "\n" +
                    "Acciones tomadas: " + accionesTomadas + "  (errores evitados: " + erroresEvitados + ")\n\n" +
                    "Alarmas detectadas por las métricas: " + totalAlarmas + "\n" +
                    "   Mostradas: " + mostradas + "  (confirmadas: " + confirmadas + ", atendidas: " + atendidas +
                    " [con error evitado: " + atendidasEvitado + "], falsas alarmas: " + falsasMostradas + ")\n" +
                    "   Descartadas por predecirse falsas: " + descartadas + "  (acertó: " + descartadasBien + ", se equivocó: " + descartadasMal + ")\n" +
                    "Errores confirmados sin alerta previa: " + sinAlerta + "\n\n" +
                    "ALERTAS CONFIRMADAS:\n" + primeras(resumenConfirmadas) + "\n\n" +
                    "ALERTAS ATENDIDAS (acción tomada):\n" + primeras(resumenAtendidas) + "\n\n" +
                    "FALSAS ALARMAS:\n" + primeras(resumenFalsas) +
                    (descartadasMal > 0 ? "\n\nALARMAS DESCARTADAS QUE SI ERAN ERROR:\n" + primeras(resumenEquivocadas) : "") +
                    (sinAlerta > 0 ? "\n\nERRORES CONFIRMADOS SIN ALERTA:\n" + primeras(resumenSinAlerta) : "") + "\n\n" +
                    "Archivos guardados en:\n" + carpeta + "\n" +
                    "  - " + System.IO.Path.GetFileName(rutaConErrores) + "\n" +
                    "  - " + System.IO.Path.GetFileName(rutaConfirmados) + "\n" +
                    "  - " + System.IO.Path.GetFileName(rutaValidadas),
                    "Resultado final");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error:\n" + ex.Message);
            }
            finally
            {
                this.Text = tituloOriginal;
                // Se quita la barra de progreso al terminar (también si hubo error o se canceló)
                if (barra != null) { this.Controls.Remove(barra); barra.Dispose(); }
                if (etiquetaProgreso != null) { this.Controls.Remove(etiquetaProgreso); etiquetaProgreso.Dispose(); }
                if (boton != null) boton.Enabled = true;
            }
        }

        // Segundo botón: lee errores_confirmados.csv (lo genera el primer botón) y abre en el
        // Bloc de notas un informe con las posibles soluciones de cada tipo de error.
        private void button2_Click(object sender, EventArgs e)
        {
            Button boton = sender as Button;
            if (boton != null) boton.Enabled = false;

            try
            {
                // ---------- Elegir el archivo de errores confirmados ----------
                string ruta;
                using (OpenFileDialog dialogo = new OpenFileDialog())
                {
                    dialogo.Title = "Selecciona errores_confirmados.csv (lo genera el primer botón)";
                    dialogo.Filter = "Errores confirmados (errores_confirmados.csv)|errores_confirmados.csv|Archivos CSV (*.csv)|*.csv|Todos los archivos (*.*)|*.*";
                    if (dialogo.ShowDialog() != DialogResult.OK)
                        return;
                    ruta = dialogo.FileName;
                }

                string carpeta = System.IO.Path.GetDirectoryName(ruta);
                string rutaInforme = System.IO.Path.Combine(carpeta, "errores_posibles_soluciones.txt");

                // ====== BASE DE SOLUCIONES (puedes agregar o editar reglas aquí) ======
                // Cada regla: título del problema, palabras clave (en minúsculas) y lista de posibles soluciones.
                // Se aplica cuando el mensaje del error contiene alguna de las palabras clave.
                var reglas = new System.Collections.Generic.List<Tuple<string, string[], string[]>>();

                reglas.Add(Tuple.Create(
                    "Saturación del pool de conexiones / demasiadas peticiones",
                    new string[] { "pool de conexiones", "pool", "peticiones", "pico de conexiones", "demasiadas conexiones", "too many" },
                    new string[] {
                        "Poner un límite de conexiones/peticiones por cliente (rate limiting) en el checkout.",
                        "Aumentar el tamaño máximo del pool de conexiones y revisar el tiempo de espera para obtener una conexión.",
                        "Cerrar o liberar las conexiones siempre (usar 'using' o 'finally') para evitar fugas.",
                        "Agregar una cola o balanceador de carga para repartir las peticiones entre varios servidores.",
                        "Activar alertas cuando el pool pase del 80 % de uso." }));

                reglas.Add(Tuple.Create(
                    "Tiempo de espera agotado (timeout)",
                    new string[] { "timeout", "tiempo de espera", "tiempo agotado", "timed out", "agotó", "agotado" },
                    new string[] {
                        "Revisar si el servicio de destino está lento o caído y ver su carga de CPU/RAM.",
                        "Aumentar el timeout solo si la operación es legítimamente lenta; no como única solución.",
                        "Optimizar la consulta o proceso que tarda (índices, caché, paginación).",
                        "Implementar reintentos con espera creciente (backoff) y un circuit breaker." }));

                reglas.Add(Tuple.Create(
                    "Memoria insuficiente (RAM)",
                    new string[] { "memoria", "ram de ", "outofmemory", "out of memory", "oom" },
                    new string[] {
                        "Buscar fugas de memoria (objetos que no se liberan, cachés sin límite, eventos sin desuscribir).",
                        "Aumentar la RAM del servidor o limitar la memoria que usa cada proceso.",
                        "Reiniciar el servicio de forma programada como medida temporal.",
                        "Revisar procesos que cargan archivos o tablas completas en memoria y procesarlos por bloques." }));

                reglas.Add(Tuple.Create(
                    "CPU saturada",
                    new string[] { "cpu de ", "cpu", "procesador" },
                    new string[] {
                        "Identificar el proceso que más CPU consume (Administrador de tareas, top, perfilador).",
                        "Optimizar bucles, consultas y tareas pesadas; moverlas a horarios de baja demanda.",
                        "Escalar: más núcleos o más servidores detrás de un balanceador.",
                        "Revisar que no haya tareas programadas (respaldo, reindexado) coincidiendo con horas pico." }));

                reglas.Add(Tuple.Create(
                    "Disco lleno o con problemas",
                    new string[] { "disco", "espacio", "no space", "disk", "i/o" },
                    new string[] {
                        "Liberar espacio: borrar logs antiguos, temporales y respaldos viejos.",
                        "Configurar rotación y compresión de logs.",
                        "Ampliar el disco o mover datos pesados a otro volumen.",
                        "Revisar la salud del disco (SMART) si hay errores de lectura/escritura." }));

                reglas.Add(Tuple.Create(
                    "Latencia alta / lentitud",
                    new string[] { "latencia", "lento", "lentitud", "demora", "slow" },
                    new string[] {
                        "Revisar la red entre servicios (saturación, DNS, balanceador).",
                        "Agregar caché para datos que se consultan seguido.",
                        "Revisar consultas lentas en la base de datos y crear los índices que falten.",
                        "Verificar si la latencia sube junto con CPU/RAM (señal de servidor saturado)." }));

                reglas.Add(Tuple.Create(
                    "Problemas con la base de datos",
                    new string[] { "base de datos", "sql", "deadlock", "bloqueo", "transacción", "transaccion", "consulta" },
                    new string[] {
                        "Revisar bloqueos y deadlocks; acortar las transacciones y mantener un orden fijo de acceso a las tablas.",
                        "Optimizar consultas lentas y crear índices.",
                        "Verificar que la base de datos acepte más conexiones y tenga recursos suficientes.",
                        "Confirmar que los respaldos o el reindexado no coinciden con la operación normal." }));

                reglas.Add(Tuple.Create(
                    "Conexión rechazada o servicio inaccesible",
                    new string[] { "rechazad", "refused", "inaccesible", "no disponible", "caído", "caido", "unreachable", "no responde", "conexión perdida", "conexion perdida" },
                    new string[] {
                        "Verificar que el servicio de destino esté en ejecución y reiniciarlo si es necesario.",
                        "Revisar el firewall, los puertos abiertos y las reglas de red.",
                        "Comprobar la dirección/puerto configurado y el DNS.",
                        "Agregar reintentos con espera y un servidor de respaldo (failover)." }));

                reglas.Add(Tuple.Create(
                    "Bloqueo del firewall / acceso denegado",
                    new string[] { "firewall", "bloquead", "denegad", "denied", "puerto", "intrusión", "intrusion", "ataque" },
                    new string[] {
                        "Revisar la regla del firewall que bloquea el tráfico y confirmar si el bloqueo es legítimo.",
                        "Si es tráfico válido, agregar la regla de excepción solo para la IP/puerto necesarios.",
                        "Si parece un ataque (muchas peticiones desde una IP), bloquear la IP y activar protección anti-DDoS.",
                        "Revisar los logs del firewall para ver el origen y la frecuencia." }));

                reglas.Add(Tuple.Create(
                    "Autenticación o permisos",
                    new string[] { "autenticación", "autenticacion", "credenciales", "contraseña", "token", "401", "403", "permiso", "unauthorized", "forbidden" },
                    new string[] {
                        "Verificar que las credenciales o tokens no hayan expirado y renovarlos.",
                        "Revisar los permisos del usuario o cuenta de servicio.",
                        "Confirmar que la hora del servidor esté sincronizada (los tokens dependen de ella)." }));

                reglas.Add(Tuple.Create(
                    "Certificado SSL/TLS",
                    new string[] { "certificado", "ssl", "tls", "https" },
                    new string[] {
                        "Revisar la fecha de vencimiento del certificado y renovarlo.",
                        "Verificar que la cadena de certificados esté completa y el nombre de dominio coincida." }));

                reglas.Add(Tuple.Create(
                    "Excepción o error interno de la aplicación",
                    new string[] { "excepción", "excepcion", "exception", "nullreference", "500", "error interno", "fallo", "falló", "fallo" },
                    new string[] {
                        "Revisar el stack trace en el log para ubicar el archivo y la línea que falla.",
                        "Reproducir el error en un entorno de pruebas con los mismos datos.",
                        "Agregar validaciones de datos nulos o vacíos antes de usarlos.",
                        "Revisar si el error empezó después de un cambio o despliegue reciente y valorar volver a la versión anterior." }));

                reglas.Add(Tuple.Create(
                    "Reintentos fallidos",
                    new string[] { "reintento", "retry" },
                    new string[] {
                        "Revisar por qué falla la operación original; los reintentos solo ocultan el problema.",
                        "Limitar el número de reintentos y usar espera creciente para no sobrecargar más el servicio." }));

                string[] solucionesGenerales = new string[] {
                    "Revisar los logs anteriores al error (se muestran abajo) para encontrar la causa inicial.",
                    "Comprobar CPU, RAM, disco y latencia en el momento del error: suelen subir antes de una falla.",
                    "Ver si coincide con un evento programado (respaldo, reindexado, campaña) o con un cambio reciente.",
                    "Si se repite, agregar una alerta específica y documentar la causa y la solución aplicada." };

                // ---------- Funciones auxiliares ----------
                // Divide una línea CSV respetando las comillas ("texto, con coma")
                Func<string, System.Collections.Generic.List<string>> dividirCsv = texto =>
                {
                    System.Collections.Generic.List<string> partes = new System.Collections.Generic.List<string>();
                    System.Text.StringBuilder actual = new System.Text.StringBuilder();
                    bool entreComillas = false;
                    for (int i = 0; i < texto.Length; i++)
                    {
                        char c = texto[i];
                        if (entreComillas)
                        {
                            if (c == '"')
                            {
                                if (i + 1 < texto.Length && texto[i + 1] == '"') { actual.Append('"'); i++; }
                                else entreComillas = false;
                            }
                            else actual.Append(c);
                        }
                        else if (c == '"') entreComillas = true;
                        else if (c == ',') { partes.Add(actual.ToString()); actual.Clear(); }
                        else actual.Append(c);
                    }
                    partes.Add(actual.ToString());
                    return partes;
                };

                // Reglas que coinciden con un texto
                Func<string, System.Collections.Generic.List<Tuple<string, string[], string[]>>> buscarReglas = texto =>
                {
                    System.Collections.Generic.List<Tuple<string, string[], string[]>> encontradas =
                        new System.Collections.Generic.List<Tuple<string, string[], string[]>>();
                    string minusculas = texto.ToLowerInvariant();
                    foreach (var regla in reglas)
                        if (Array.Exists(regla.Item2, palabra => minusculas.Contains(palabra)))
                            encontradas.Add(regla);
                    return encontradas;
                };

                // ---------- Leer los errores confirmados ----------
                // Columnas: grupo, rol, timestamp_log, fuente, nivel, mensaje, timestamp_csv, errores_csv
                System.Collections.Generic.List<string[]> filas = new System.Collections.Generic.List<string[]>();
                bool primera = true;
                foreach (string linea in System.IO.File.ReadLines(ruta, System.Text.Encoding.UTF8))
                {
                    if (primera) { primera = false; continue; } // encabezado
                    if (string.IsNullOrWhiteSpace(linea)) continue;

                    System.Collections.Generic.List<string> campos = dividirCsv(linea);
                    if (campos.Count < 6) continue;
                    filas.Add(campos.ToArray());
                }

                if (filas.Count == 0)
                {
                    MessageBox.Show("El archivo no tiene errores confirmados.\n\nEjecuta primero el primer botón para generarlo.");
                    return;
                }

                // Agrupa las filas por número de grupo (cada grupo = un error + sus logs anteriores)
                System.Collections.Generic.List<string> ordenGrupos = new System.Collections.Generic.List<string>();
                System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string[]>> porGrupo =
                    new System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string[]>>();
                foreach (string[] fila in filas)
                {
                    if (!porGrupo.ContainsKey(fila[0]))
                    {
                        porGrupo[fila[0]] = new System.Collections.Generic.List<string[]>();
                        ordenGrupos.Add(fila[0]);
                    }
                    porGrupo[fila[0]].Add(fila);
                }

                // Agrupa los errores iguales (mismo mensaje sin contar los números y misma fuente)
                System.Collections.Generic.List<string> ordenTipos = new System.Collections.Generic.List<string>();
                System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string>> gruposPorTipo =
                    new System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string>>();

                foreach (string grupo in ordenGrupos)
                {
                    string[] filaError = porGrupo[grupo].Find(f => f[1].Equals("ERROR CONFIRMADO", StringComparison.OrdinalIgnoreCase));
                    if (filaError == null) continue;

                    string firma = filaError[3].Trim().ToLowerInvariant() + "|" +
                        System.Text.RegularExpressions.Regex.Replace(filaError[5].Trim().ToLowerInvariant(), @"\d+", "#");

                    if (!gruposPorTipo.ContainsKey(firma))
                    {
                        gruposPorTipo[firma] = new System.Collections.Generic.List<string>();
                        ordenTipos.Add(firma);
                    }
                    gruposPorTipo[firma].Add(grupo);
                }

                // Los tipos más frecuentes primero
                ordenTipos.Sort((x, y) => gruposPorTipo[y].Count.CompareTo(gruposPorTipo[x].Count));

                // ---------- Armar el informe ----------
                string linea80 = new string('=', 80);
                string lineaFina = new string('-', 80);
                System.Text.StringBuilder informe = new System.Text.StringBuilder();

                informe.AppendLine(linea80);
                informe.AppendLine("  ERRORES CONFIRMADOS: POSIBLES SOLUCIONES");
                informe.AppendLine(linea80);
                informe.AppendLine("Generado:            " + DateTime.Now.ToString("yyyy-MM-dd HH:mm"));
                informe.AppendLine("Archivo analizado:   " + System.IO.Path.GetFileName(ruta));
                informe.AppendLine("Errores confirmados: " + ordenGrupos.Count);
                informe.AppendLine("Tipos distintos:     " + ordenTipos.Count);
                informe.AppendLine();
                informe.AppendLine("Nota: son posibles causas y soluciones basadas en el texto de cada error.");
                informe.AppendLine("Confírmalas revisando el sistema antes de aplicar cambios.");

                int numeroTipo = 0;
                foreach (string firma in ordenTipos)
                {
                    numeroTipo++;
                    System.Collections.Generic.List<string> listaGrupos = gruposPorTipo[firma];

                    string[] primerError = porGrupo[listaGrupos[0]].Find(f => f[1].Equals("ERROR CONFIRMADO", StringComparison.OrdinalIgnoreCase));
                    string[] ultimoError = porGrupo[listaGrupos[listaGrupos.Count - 1]].Find(f => f[1].Equals("ERROR CONFIRMADO", StringComparison.OrdinalIgnoreCase));

                    informe.AppendLine();
                    informe.AppendLine(linea80);
                    informe.AppendLine("ERROR " + numeroTipo + " de " + ordenTipos.Count +
                                       "   (ocurrió " + listaGrupos.Count + (listaGrupos.Count == 1 ? " vez)" : " veces)"));
                    informe.AppendLine(linea80);
                    informe.AppendLine("Fuente:   " + primerError[3]);
                    informe.AppendLine("Mensaje:  " + primerError[5]);
                    informe.AppendLine("Primera:  " + primerError[2].Replace("T", " "));
                    if (listaGrupos.Count > 1)
                        informe.AppendLine("Última:   " + ultimoError[2].Replace("T", " "));

                    // Logs anteriores del primer error (contexto)
                    System.Collections.Generic.List<string[]> anteriores = porGrupo[listaGrupos[0]].FindAll(
                        f => !f[1].Equals("ERROR CONFIRMADO", StringComparison.OrdinalIgnoreCase));
                    if (anteriores.Count > 0)
                    {
                        informe.AppendLine();
                        informe.AppendLine("Logs anteriores (primera vez):");
                        foreach (string[] anterior in anteriores)
                        {
                            string hora = anterior[2].Contains("T") ? anterior[2].Substring(anterior[2].IndexOf('T') + 1) : anterior[2];
                            informe.AppendLine("   " + hora + "  " + anterior[3] + "  " + anterior[4] + "  " + anterior[5]);
                        }
                    }

                    // Buscar reglas: primero en el mensaje del error; si no hay, en los logs anteriores
                    var coincidencias = buscarReglas(primerError[5]);
                    if (coincidencias.Count == 0 && anteriores.Count > 0)
                    {
                        System.Text.StringBuilder contexto = new System.Text.StringBuilder();
                        foreach (string[] anterior in anteriores) contexto.Append(anterior[5]).Append(' ');
                        coincidencias = buscarReglas(contexto.ToString());
                    }

                    informe.AppendLine();
                    informe.AppendLine(lineaFina);

                    if (coincidencias.Count == 0)
                    {
                        informe.AppendLine("POSIBLES SOLUCIONES (generales, no se reconoció un patrón conocido):");
                        for (int s = 0; s < solucionesGenerales.Length; s++)
                            informe.AppendLine("   " + (s + 1) + ". " + solucionesGenerales[s]);
                    }
                    else
                    {
                        foreach (var regla in coincidencias)
                        {
                            informe.AppendLine("POSIBLE CAUSA: " + regla.Item1);
                            informe.AppendLine("Posibles soluciones:");
                            for (int s = 0; s < regla.Item3.Length; s++)
                                informe.AppendLine("   " + (s + 1) + ". " + regla.Item3[s]);
                            informe.AppendLine();
                        }
                    }
                }

                informe.AppendLine();
                informe.AppendLine(linea80);
                informe.AppendLine("FIN DEL INFORME");
                informe.AppendLine(linea80);

                // ---------- Guardar y abrir en el Bloc de notas ----------
                System.IO.File.WriteAllText(rutaInforme, informe.ToString(), new System.Text.UTF8Encoding(true));
                System.Diagnostics.Process.Start("notepad.exe", "\"" + rutaInforme + "\"");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error:\n" + ex.Message);
            }
            finally
            {
                if (boton != null) boton.Enabled = true;
            }
        }
    }
   }

